package de.robv.android.xposed.installer2.repo;


public class Repository {
	public String name;
	public String url;
	public boolean isPartial = false;
	public String partialUrl;
	public String version;

	/*package*/ Repository() {};
}
